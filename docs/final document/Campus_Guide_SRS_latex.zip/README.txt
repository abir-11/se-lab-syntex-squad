Campus Guide — Software Requirements Specification (LaTeX Source)
================================================================

Contents
--------
  Campus-Guide-SRS.tex   Full SRS source (17 chapters + Appendices A–J)
  figures/               All 10 diagrams as high-resolution PNGs
  README.txt             This file

How to compile
--------------
Option 1 (recommended, no installation): upload this folder to
https://overleaf.com as a new project and set Main document to "Campus-Guide-SRS.tex", choose XeLaTeX in Menu → Compiler, and press "Recompile".

Option 2 (local): run pdflatex twice from this folder:

    pdflatex Campus-Guide-SRS.tex
    pdflatex Campus-Guide-SRS.tex   (second pass fills the ToC/LoF/LoT)

Required LaTeX packages (all included in TeX Live / MiKTeX full):
  geometry, longtable, booktabs, array, ragged2e, graphicx, float,
  xcolor, caption, fancyhdr, pifont, enumitem, hyperref,
  newtxtext, newtxmath

Build verification
------------------
This project was clean-compiled successfully with Tectonic/XeLaTeX on
22 September 2026. The source contains no bibliography dependency.

Note: newtxtext/newtxmath provide the Times-like serif font. If your
installation lacks them, replace that line in the preamble with:
  \usepackage{mathptmx}
(or delete the line entirely to use the default Computer Modern font).

How to edit
-----------
- All content is plain LaTeX: headings use \chapter*{...}/\section*{...}
  with explicit numbers (e.g., "Chapter 1 --- Introduction", "7.4 Core
  Business Functions"), so you can renumber freely.
- Requirement tables are ordinary longtable environments — edit rows
  like any table.
- The cover page data (title, prepared by, date, status) is in the
  \begin{titlepage} block near the top.
- To replace a diagram, overwrite the matching PNG in figures/ (e.g.,
  figures/usecase.png). Captions are in the \begin{figure} blocks.
- The Table of Contents, List of Figures and List of Tables are
  generated automatically on the second compile pass.
