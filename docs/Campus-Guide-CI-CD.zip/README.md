# Campus Guide — GitHub CI/CD Pipeline

Ready-to-drop-in GitHub Actions configuration for the Campus Guide platform
(Next.js 14 + Prisma + PostgreSQL/MongoDB, deployed on Vercel).

![Pipeline](pipeline-diagram.png)

## What's included

| File | Purpose |
|---|---|
| `.github/workflows/ci.yml` | Every PR/push to `main`: lint, type-check, unit tests, build, plus integration tests against a real PostgreSQL 16 service container |
| `.github/workflows/deploy.yml` | Push to `main` builds with production env and deploys to Vercel, then runs smoke tests against the live URL |
| `.github/workflows/codeql.yml` | CodeQL security scan on every PR and weekly on schedule |
| `.github/dependabot.yml` | Weekly dependency update PRs (grouped minor/patch) + Actions updates |
| `pipeline-diagram.png` | The flow, drawn in the same style as your SRS figures |

## Installation (5 minutes, once the repo exists)

1. **Copy `.github/` into your repository root** and push.
2. **Connect the Vercel GitHub app** to the repo (Settings → Integrations). This
   gives every open PR a live preview URL automatically — no workflow needed for that.
3. **Create the secrets** in GitHub → Settings → Secrets and variables → Actions:

   | Secret | Where to get it |
   |---|---|
   | `VERCEL_TOKEN` | vercel.com → Settings → Tokens (create one) |
   | `VERCEL_ORG_ID` | Vercel dashboard → your team → Settings → General |
   | `VERCEL_PROJECT_ID` | Project → Settings → General |
   | `PROD_URL` | Your production URL, e.g. `https://campus-guide.vercel.app` |

4. **Create a "production" GitHub Environment** (Settings → Environments) and put
   `PROD_URL` in it, so you can later require manual approval before deploys.
5. **Protect the main branch** (Settings → Branches → Add rule for `main`):
   - Require a pull request before merging
   - Require status checks: `Lint, Type-check, Unit Tests, Build`, `Integration Tests (real PostgreSQL)`, `Analyze (javascript-typescript)`
   - Require branches to be up to date before merging

## Required package.json scripts

The workflows call these scripts — keep the names identical when you scaffold the app:

```json
{
  "scripts": {
    "lint": "next lint",
    "typecheck": "tsc --noEmit",
    "test:cov": "vitest run --coverage",
    "test:int": "vitest run --config vitest.integration.config.ts",
    "build": "next build"
  }
}
```

## How the flow works

1. **Feature branch** → open a PR.
2. **CI gate** runs: lint → Prisma generate → type-check → unit tests → build
   (with dummy service URLs), then integration tests run migrations against a
   real PostgreSQL 16 container and execute the DB-dependent tests.
3. **CodeQL** scans the diff for security vulnerabilities.
4. Vercel posts a **preview URL** on the PR automatically.
5. **Merge to main** → `deploy.yml` runs `vercel pull → build → deploy --prebuilt --prod`,
   then the smoke test confirms the homepage returns HTTP 200.
6. Failures anywhere block the merge; the pipeline diagram above shows the full loop.

## Design notes (why it's built this way)

- **Deployments happen from GitHub Actions, not only Vercel's auto-deploy**, so
  production ships only after the full CI gate passes. Set Vercel's own Git
  production deploys to "Ignored Build Step: Disabled" to avoid double deploys.
- **`--prebuilt` deploy** means the artifact tested in CI is byte-for-byte the
  artifact deployed — no rebuild on Vercel's side.
- **PostgreSQL service container** in CI keeps integration tests honest without
  paying for a cloud test database; the same migrations you run in prod
  (`prisma migrate deploy`) run in CI first.
- **Secrets never live in code.** All tokens are GitHub Environment secrets;
  CI uses throwaway values for services it doesn't touch.
